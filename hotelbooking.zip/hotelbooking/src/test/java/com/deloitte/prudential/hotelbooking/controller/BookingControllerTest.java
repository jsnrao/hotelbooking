/**
 * 
 */
package com.deloitte.prudential.hotelbooking.controller;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.deloitte.prudential.hotelbooking.model.Booking;
import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.model.Hotel;
import com.deloitte.prudential.hotelbooking.service.BookingService;

/**
 * @author jsnsa
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class BookingControllerTest {

	@Autowired
	public BookingController bookingController;
	@Mock
	public BookingService bookingService;
	
	private Booking booking1;
	private Booking booking2; 
	private Hotel hotel1;
	private Hotel hotel2;
	private Customer customer1;
	private Customer customer2;
	
	@Mock
	ResponseEntity<Booking> successResponseEntity = new ResponseEntity<>(booking1, HttpStatus.CREATED);
	@Mock
	ResponseEntity<Booking> failureResponseEntity = new ResponseEntity<>(booking1, HttpStatus.BAD_REQUEST);


	@BeforeEach
	public void setUp() {
		hotel1= new Hotel("Id1","Premierin");
		hotel2= new Hotel("Id2","Holidayin");
		customer1 = new Customer("Id1","customer1", "customer1@test.com");
		customer2 = new Customer("Id2","customer2","customer2@test.com");
		booking1 = new Booking(1, false, hotel1, customer1);
		booking2 = new Booking(2, false, hotel1, customer2);
	}
	
	@Test
	public void testCreateBooking() {
		booking1.setId("5b13ec8911720409b4ab235a");
		when(bookingService.saveBooking(booking1)).thenReturn(successResponseEntity);
		ResponseEntity<Booking> responseEntity = bookingController.saveBooking(booking1);
		assertEquals(200,responseEntity.getStatusCode().value());
	}
	@Test
	public void testCreateBookingWithNull() {
		when(bookingService.saveBooking(null)).thenReturn(failureResponseEntity);
		ResponseEntity<Booking> responseEntity = bookingController.saveBooking(null);
		assertEquals(400,responseEntity.getStatusCode().value());
	}
	
	@Test
	public void testUpdateBooking() {
		when(bookingService.updateBooking(booking1)).thenReturn(successResponseEntity);
		booking1.setId("5b13ec8911720409b4ab235a");
		ResponseEntity<Booking> responseEntity = bookingController.updateBooking(booking1);
		assertEquals(200,responseEntity.getStatusCode().value());
	}
	
	@Test
	public void testUpdateBookingWithNull() {
		when(bookingService.updateBooking(null)).thenReturn(failureResponseEntity);
		ResponseEntity<Booking> responseEntity = bookingController.updateBooking(null);
		assertEquals(400,responseEntity.getStatusCode().value());
	}
	@Test
	public void testFetchBookingDetails() {
		when(bookingService.fetchAllBooking()).thenReturn(Arrays.asList(booking1,booking2));
		ResponseEntity<Booking> responseEntity = bookingController.updateBooking(booking1);
		assertEquals(200,responseEntity.getStatusCode().value());
	}
	
	@Test
	public void testFetchBookingById() {
		when(bookingService.findBookingById("")).thenReturn(Optional.of(booking1));
		Optional<Booking> responseEntity = bookingController.getBookingById("5b13ec8911720409b4ab235a");
		assertEquals("5b13ec8911720409b4ab235a",responseEntity.get().getId());
	}
	
}
