/**
 * 
 */
package com.deloitte.prudential.hotelbooking.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.deloitte.prudential.hotelbooking.model.Hotel;
import com.deloitte.prudential.hotelbooking.repository.HotelRepository;
import com.deloitte.prudential.hotelbooking.service.HotelService;

/**
 * @author jsnsa
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class HotelServiceTest {

	@Mock
	private HotelRepository hotelRepository;
	@Autowired
	private HotelService hotelService;
	
	private Hotel hotel1;
	private Hotel hotel2;
 
	@BeforeEach
	public void setup() {
		hotel1 = new Hotel("HolidayInn");
		hotel2 = new Hotel("Premierin");
	}
	
	@Test
	public void testFetchAllHotels() {
		 when(hotelRepository.findAll()).thenReturn(Arrays.asList(hotel1,hotel2));
		 List<Hotel> availableHotels = hotelService.fetchAllHotels();
		 assertEquals(availableHotels.size(), 2);
	}
	
	@Test
	public void testSaveHotel() {
		when(hotelRepository.save(hotel1)).thenReturn(hotel1);
		ResponseEntity<Hotel> hotel = hotelService.saveHotel(hotel1);
		assertNotNull(hotel);
	}
	
	@Test
	public void testUpdateHotel() {
		when(hotelRepository.save(hotel1)).thenReturn(hotel1);
		hotel1.setId("abcd-cda-123-1231231");
		ResponseEntity<Hotel> hotel = hotelService.saveHotel(hotel1);
		assertNotNull(hotel);
	}
	
	@Test
	public void testSaveHotelWithNull() {
		when(hotelRepository.save(null)).thenReturn(hotel1);
		ResponseEntity<Hotel> hotel = hotelService.saveHotel(null);
		assertEquals(400, hotel.getStatusCode().value());
	}
	
	@Test
	public void testUpdateHotelWithNull() {
		when(hotelRepository.save(null)).thenReturn(hotel1);
		hotel1.setId("abcd-cda-123-1231231");
		ResponseEntity<Hotel> hotel = hotelService.saveHotel(null);
		assertEquals(400, hotel.getStatusCode().value());
	}
	
}
