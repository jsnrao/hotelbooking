/**
 * 
 */
package com.deloitte.prudential.hotelbooking.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.service.CustomerService;

/**
 * @author jsnsa
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CustomerControllerTest {

	@Autowired
	private CustomerContoller customerController;

	@Mock
	private CustomerService customerService;

	private Customer customer1;
	private Customer customer2;
	
	@Mock
	ResponseEntity<Customer> successResponseEntity = new ResponseEntity<>(customer1, HttpStatus.CREATED);
	@Mock
	ResponseEntity<Customer> failureResponseEntity = new ResponseEntity<>(customer1, HttpStatus.BAD_REQUEST);


	@BeforeEach
	public void setUp() {
		customer1 = new Customer("test1", "test1@deloitte.com");
		customer2 = new Customer("test2", "test2@deloitte.com");

	}

	

	@Test
	public void testFetchAllCustomers() {
		when(customerService.fetchAllCustomer()).thenReturn(Arrays.asList(customer1,customer2));
		List<Customer> listOfCustomers = new ArrayList<>();
		listOfCustomers = customerController.getCustomerDetails();
		assertNotNull(listOfCustomers);
		assertEquals(2, listOfCustomers.size());
	}

	@Test
	public void testAddCustomer() {
		when(customerService.saveCustomer(customer1)).thenReturn(successResponseEntity);
		customer1.setId("5b13ec8911720409b4ab235a");
		ResponseEntity<Customer> responseEntity = customerController.saveCustomer(customer1);
		assertEquals(201, responseEntity.getStatusCode().value());
	}

	@Test
	public void testUpdateCustomer() {
		when(customerService.updateCustomer(customer1)).thenReturn(successResponseEntity);
		customer1.setId("5b13ec8911720409b4ab235a");
		ResponseEntity<Customer> responseEntity = customerController.updateCustomer(customer1);
		assertEquals(201, responseEntity.getStatusCode().value());
	}
	
	@Test
	public void testAddCustomerWithNull() {
		when(customerService.saveCustomer(null)).thenReturn(successResponseEntity);
		ResponseEntity<Customer> responseEntity = customerController.saveCustomer(null);
		assertEquals(400, responseEntity.getStatusCode().value());
	}

	@Test
	public void testUpdateCustomerWithNull() {
		when(customerService.updateCustomer(null)).thenReturn(successResponseEntity);
		ResponseEntity<Customer> responseEntity = customerController.updateCustomer(null);
		assertEquals(400, responseEntity.getStatusCode().value());
	}
	
	@Test
	public void testFetchCustomerById() {
		customer1.setId("5b13ec8911720409b4ab235a");
		when(customerService.findCustomerById("5b13ec8911720409b4ab235a")).thenReturn(Optional.of(customer1));
		Optional<Customer> customer = customerController.fetchByCustomerId("5b13ec8911720409b4ab235a");
		assertEquals("5b13ec8911720409b4ab235a",customer.get().getId());
	}


}
