/**
 * 
 */
package com.deloitte.prudential.hotelbooking.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.repository.CustomerRepository;
import com.deloitte.prudential.hotelbooking.service.CustomerService;

/**
 * @author jsnsa
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CustomerServiceTest {

	@Autowired
	private CustomerService customerService;

	@Mock
	private CustomerRepository customerRepository;

	private Customer customer1;
	private Customer customer2;

	@BeforeEach
	public void setUp() {
		customer1 = new Customer("test1", "test1@deloitte.com");
		customer2 = new Customer("test2", "test2@deloitte.com");
	}

	@Test
	public void testFindCustomer() {

	}

	@Test
	public void testFetchAllCustomers() {
		when(customerRepository.findAll()).thenReturn(Arrays.asList(customer1,customer2));
		List<Customer> listOfCustomers = new ArrayList<>();
		listOfCustomers = customerService.fetchAllCustomer();
		assertNotNull(listOfCustomers);
		assertEquals(2, listOfCustomers.size());
	}

	@Test
	public void testAddCustomer() {
		when(customerRepository.save(customer1)).thenReturn(customer1);
		ResponseEntity<Customer> responseEntity = customerService.saveCustomer(customer1);
		assertNotNull(responseEntity);
	}

	@Test
	public void testUpdateCustomer() {
		when(customerRepository.save(customer1)).thenReturn(customer1);
		ResponseEntity<Customer> responseEntity = customerService.updateCustomer(customer1);
		assertNotNull(responseEntity);
	}

	@Test
	public void testAddCustomerWitNull() {
		when(customerRepository.save(null)).thenReturn(customer1);
		ResponseEntity<Customer> responseEntity = customerService.saveCustomer(null);
		assertNotNull(responseEntity);
	}

	@Test
	public void testUpdateCustomerWithNull() {
		when(customerRepository.save(null)).thenReturn(customer1);
		ResponseEntity<Customer> responseEntity = customerService.updateCustomer(null);
		assertNotNull(responseEntity);
	}
	

}
