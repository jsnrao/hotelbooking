/**
 * 
 */
package com.deloitte.prudential.hotelbooking.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.deloitte.prudential.hotelbooking.model.Booking;
import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.model.Hotel;
import com.deloitte.prudential.hotelbooking.repository.BookingRepository;

/**
 * @author jsnsa
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class BookingServiceTest {

	@Mock
	public BookingRepository bookingRepository;
	@Autowired
	public BookingService bookingService;
	
	private Booking booking1;
	private Booking booking2; 
	private Hotel hotel1;
	private Hotel hotel2;
	private Customer customer1;
	private Customer customer2;

	
	@BeforeEach
	public void setUp() {
		hotel1= new Hotel("Id1","Premierin");
		hotel2= new Hotel("Id2","Holidayin");
		customer1 = new Customer("Id1","customer1", "customer1@test.com");
		customer2 = new Customer("Id2","customer2","customer2@test.com");
		booking1 = new Booking(1, false, hotel1, customer1);
		booking2 = new Booking(2, false, hotel1, customer2);
	}
	
	@Test
	public void testCreateBooking() {
		when(bookingRepository.save(booking1)).thenReturn(booking1);
		ResponseEntity<Booking> responseEntity = bookingService.updateBooking(booking1);
		assertNotNull(responseEntity);
	}
	
	@Test
	public void testUpdateBooking() {
		when(bookingRepository.save(booking1)).thenReturn(booking1);
		ResponseEntity<Booking> responseEntity = bookingService.saveBooking(booking1);
		assertNotNull(responseEntity);
	}
	
	@Test
	public void testFetchBookingDetails() {
		when(bookingRepository.findAll()).thenReturn(Arrays.asList(booking1,booking2));
		List<Booking> responseEntity = bookingService.fetchAllBooking();
		assertNotNull(responseEntity);
	}
}
