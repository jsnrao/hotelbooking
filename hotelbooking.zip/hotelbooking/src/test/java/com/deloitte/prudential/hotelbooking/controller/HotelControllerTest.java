/**
 * 
 */
package com.deloitte.prudential.hotelbooking.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.model.Hotel;
import com.deloitte.prudential.hotelbooking.service.HotelService;

/**
 * @author jsnsa
 *
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class HotelControllerTest {

	@Mock
	private HotelService hotelService;
	@Autowired
	private HotelController hotelController;
	
	private Hotel hotel1;
	private Hotel hotel2;
	@Mock
	ResponseEntity<Hotel> successResponseEntity = new ResponseEntity<>(hotel1, HttpStatus.CREATED);
	@Mock
	ResponseEntity<Hotel> failureResponseEntity = new ResponseEntity<>(hotel1, HttpStatus.BAD_REQUEST);

	

	@BeforeEach
	public void setup() {
		hotel1 = new Hotel("HolidayInn");
		hotel2 = new Hotel("Premierin");
		
	}

	@Test
	public void testFetchAllHotels() {

		List<Hotel> hotels = new ArrayList<>();
		hotels.add(hotel1);
		hotels.add(hotel2);
		when(hotelService.fetchAllHotels()).thenReturn(hotels);
		List<Hotel> availableHotels = new ArrayList<>();

		availableHotels = hotelController.getAvailableHotels();
		assertEquals(2, availableHotels.size());
	}

	@Test
	public void testSaveHotel() {
		when(hotelService.saveHotel(hotel1)).thenReturn(successResponseEntity);
		ResponseEntity<Hotel> responseEntity = hotelController.saveHotel(hotel1);
		assertEquals(201, responseEntity.getStatusCode().value());
	}

	@Test
	public void testUpdateHotel() {
		when(hotelService.updateHotel(hotel1)).thenReturn(successResponseEntity);
		hotel1.setId("abcd-cda-123-1231231");
		ResponseEntity<Hotel> responseUpdateEntity = hotelController.updateHotel(hotel1);
		assertEquals(201, responseUpdateEntity.getStatusCode().value());
	}
	
	@Test
	public void testSaveHotelWithNull() {
		when(hotelService.saveHotel(null)).thenReturn(successResponseEntity);
		ResponseEntity<Hotel> responseEntity = hotelController.saveHotel(null);
		assertEquals(400, responseEntity.getStatusCode().value());
	}

	@Test
	public void testUpdateHotelWithNull() {
		when(hotelService.updateHotel(null)).thenReturn(successResponseEntity);
		hotel1.setId("abcd-cda-123-1231231");
		ResponseEntity<Hotel> responseUpdateEntity = hotelController.updateHotel(null);
		assertEquals(400, responseUpdateEntity.getStatusCode().value());
	}

	
	@Test
	public void testFetchHotelById() {
		hotel1.setId("abcd-cda-123-1231231");
		when(hotelService.findHotelById("abcd-cda-123-1231231")).thenReturn(Optional.of(hotel1));
		Optional<Hotel> responseEntity =hotelController.getHotelById("abcd-cda-123-1231231");
		assertEquals("abcd-cda-123-1231231",responseEntity.get().getId());
	}

	

}
