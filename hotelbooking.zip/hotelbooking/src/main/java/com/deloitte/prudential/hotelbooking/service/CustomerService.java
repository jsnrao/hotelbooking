package com.deloitte.prudential.hotelbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.deloitte.prudential.hotelbooking.model.Customer;

public interface CustomerService {

	ResponseEntity<Customer> saveCustomer(Customer customer);
	
	ResponseEntity<Customer> updateCustomer(Customer customer);
	
	void deleteCustomer(Customer customer);
	
	List<Customer> fetchAllCustomer();

	Optional<Customer> findCustomerById(String id);
}
