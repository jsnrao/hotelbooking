package com.deloitte.prudential.hotelbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deloitte.prudential.hotelbooking.model.Hotel;
import com.deloitte.prudential.hotelbooking.repository.HotelRepository;

@Service
public class HotelServiceImpl implements HotelService {

	@Autowired
	private HotelRepository hotelRepository;
	
	@Override
	public ResponseEntity<Hotel> saveHotel(Hotel hotel) {
		ResponseEntity<Hotel> result = null;
		if(null!=hotel) {
			hotelRepository.save(hotel);
			result = new ResponseEntity<>(hotel,HttpStatus.CREATED);
		}else {
			result = new ResponseEntity<>(hotel,HttpStatus.BAD_REQUEST);
		}
		return result;
		
	}

	@Override
	public ResponseEntity<Hotel> updateHotel(Hotel hotel) {
		ResponseEntity<Hotel> result = null;
		if(null!=hotel && null!=hotel.getId()) {
			hotelRepository.save(hotel);
			result = new ResponseEntity<>(hotel,HttpStatus.CREATED);
		}else {
			result = new ResponseEntity<>(hotel,HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@Override
	public void deleteHotel(Hotel hotel) {
		hotelRepository.delete(hotel);

	}

	@Override
	public List<Hotel> fetchAllHotels() {
		return hotelRepository.findAll();
	}

	@Override
	public Optional<Hotel> findHotelById(String id) {
		return hotelRepository.findById(id);
	}

}
