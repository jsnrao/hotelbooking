package com.deloitte.prudential.hotelbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public ResponseEntity<Customer> saveCustomer(Customer customer) {
		ResponseEntity<Customer> result = null;
		if (null != customer) {
			customerRepository.save(customer);
			result = new ResponseEntity<>(customer, HttpStatus.CREATED);
		} else {
			result = new ResponseEntity<>(customer, HttpStatus.BAD_REQUEST);
		}
		return result;

	}

	@Override
	public ResponseEntity<Customer> updateCustomer(Customer customer) {
		ResponseEntity<Customer> result = null;
		if (null != customer) {
			customerRepository.save(customer);
			result = new ResponseEntity<>(customer, HttpStatus.CREATED);
		} else {
			result = new ResponseEntity<>(customer, HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	@Override
	public void deleteCustomer(Customer customer) {
		customerRepository.delete(customer);
	}

	@Override
	public List<Customer> fetchAllCustomer() {
		return customerRepository.findAll();
	}

	@Override
	public Optional<Customer> findCustomerById(String id) {
		return customerRepository.findById(id);
				
	}

}
