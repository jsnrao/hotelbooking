package com.deloitte.prudential.hotelbooking.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.deloitte.prudential.hotelbooking.service.NotificationService;

/**
 * Controller for email notification for sending all hotelbooking/cancellation  related confirmations
 * @author jsnsa
 *
 */
@Controller
public class NotificationController {
    
    @Autowired
    private NotificationService notificationService;

    @RequestMapping("/notifcation")
    @ResponseBody
    String home(@RequestParam (value="message") String message,@RequestParam (value="email") String email) {
        try {
            notificationService.sendNotification(message,email);
            return "Notification Sent!";
        }catch(Exception ex) {
            return "Error in sending Notifiction: "+ex;
        }
    }

   
}