package com.deloitte.prudential.hotelbooking.service;

public interface NotificationService {
	
	void sendNotification(String message,String email)throws Exception;

}
