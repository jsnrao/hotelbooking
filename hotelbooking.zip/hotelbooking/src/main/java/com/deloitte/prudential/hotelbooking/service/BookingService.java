package com.deloitte.prudential.hotelbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.deloitte.prudential.hotelbooking.model.Booking;

public interface BookingService {
	
	ResponseEntity<Booking> saveBooking(Booking booking);
	
	ResponseEntity<Booking> updateBooking(Booking booking);
	
	void deleteBooking(Booking booking);
	
	List<Booking> fetchAllBooking();

	Optional<Booking> findBookingById(String id);
	

}
