package com.deloitte.prudential.hotelbooking.service;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.deloitte.prudential.hotelbooking.constants.ApplicationConstants;

@Service
public class NotificationSericeImpl implements NotificationService {

	@Autowired
	private JavaMailSender notificationSender;

	@Override
	public void sendNotification(String emailData, String email) throws Exception {
		 MimeMessage message = notificationSender.createMimeMessage();
	        MimeMessageHelper helper = new MimeMessageHelper(message);
	        
	        helper.setTo(email);
	        helper.setText(emailData);
	        helper.setSubject(ApplicationConstants.EMAIL_SUBJECT);
	        
	        notificationSender.send(message);
	};

	
}
