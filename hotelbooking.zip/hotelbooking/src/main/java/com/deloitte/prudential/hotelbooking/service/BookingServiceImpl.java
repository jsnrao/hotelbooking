package com.deloitte.prudential.hotelbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.deloitte.prudential.hotelbooking.model.Booking;
import com.deloitte.prudential.hotelbooking.repository.BookingRepository;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;

	@Override
	public ResponseEntity<Booking> saveBooking(Booking booking) {

		ResponseEntity<Booking> result = null;
		if (null != booking && null != booking.getCustomer()
				&& null != booking.getCustomer().getId() && null != booking.getHotel()
				&& null != booking.getHotel().getId()) {
			 bookingRepository.save(booking);
			//NOTE: SMTP properties needs to be corrected inorder to send notifications
				/*try {
					notificationService.sendNotification("Hotel Booking Updated", booking.getCustomer().getEmail());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	*/	
			result = new ResponseEntity<>(booking,HttpStatus.OK);
		}else {
			result = new ResponseEntity<>(booking,HttpStatus.BAD_REQUEST);
			//NOTE: SMTP properties needs to be corrected inorder to send notifications
			/*try {
				notificationService.sendNotification("Unable to update hotel booking", booking.getCustomer().getEmail());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
*/	}
		return result;
	}

	@Override
	public ResponseEntity<Booking> updateBooking(Booking booking) {

		ResponseEntity<Booking> result = null;
		if (null != booking && null != booking.getId() && null != booking.getCustomer()
				&& null != booking.getCustomer().getId() && null != booking.getHotel()
				&& null != booking.getHotel().getId()) {
			 bookingRepository.save(booking);
			//NOTE: SMTP properties needs to be corrected inorder to send notifications
				/*try {
					notificationService.sendNotification("Hotel Booking Updated", booking.getCustomer().getEmail());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	*/	
			result = new ResponseEntity<>(booking,HttpStatus.OK);
		}else {
			result = new ResponseEntity<>(booking,HttpStatus.BAD_REQUEST);
			//NOTE: SMTP properties needs to be corrected inorder to send notifications
			/*try {
				notificationService.sendNotification("Unable to update hotel booking", booking.getCustomer().getEmail());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
*/	}
		return result;

	}

	@Override
	public void deleteBooking(Booking booking) {
		bookingRepository.delete(booking);

	}

	@Override
	public List<Booking> fetchAllBooking() {
		return bookingRepository.findAll();
	}

	@Override
	public Optional<Booking> findBookingById(String id) {
		return bookingRepository.findById(id);
	}
	
}
