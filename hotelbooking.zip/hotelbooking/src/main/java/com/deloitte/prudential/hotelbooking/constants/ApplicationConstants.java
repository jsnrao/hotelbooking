package com.deloitte.prudential.hotelbooking.constants;

public class ApplicationConstants {
	
	public static String EMAIL_SUBJECT = "Hotel Booking information";

}
