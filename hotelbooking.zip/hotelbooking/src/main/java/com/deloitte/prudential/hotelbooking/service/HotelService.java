package com.deloitte.prudential.hotelbooking.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.deloitte.prudential.hotelbooking.model.Hotel;

public interface HotelService {
	
	ResponseEntity<Hotel> saveHotel(Hotel hotel);
	
	ResponseEntity<Hotel> updateHotel(Hotel hotel);
	
	void deleteHotel(Hotel hotel);
	
	List<Hotel> fetchAllHotels();
	
	Optional<Hotel> findHotelById(String id);

}
