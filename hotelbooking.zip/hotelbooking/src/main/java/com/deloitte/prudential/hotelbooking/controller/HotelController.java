package com.deloitte.prudential.hotelbooking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.prudential.hotelbooking.model.Hotel;
import com.deloitte.prudential.hotelbooking.service.HotelService;
import com.deloitte.prudential.hotelbooking.service.NotificationService;

/**
 * Controller for creating/updating/deleting/fetching hotel
 * @author jsnsa
 *
 */
@RestController
public class HotelController {
	
	@Autowired
	private HotelService hotelService;

	
	@GetMapping(value="/fetchAllHotelDetails", produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public List<Hotel> getAvailableHotels() {
		return hotelService.fetchAllHotels();
	}
	
	@GetMapping(value="/fetchHotelById/{id}", produces = {
	        MediaType.APPLICATION_JSON_VALUE})
	public Optional<Hotel> getHotelById(@PathVariable (value="id") String id) {
		return hotelService.findHotelById(id);
	}

	
	@PostMapping(value="/saveHotelDetails", produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    }, consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public ResponseEntity<Hotel> saveHotel(@RequestBody Hotel hotel) {
		return hotelService.saveHotel(hotel);
	}
	
	@PutMapping(value="/updateHotelDetails", produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    }, consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public ResponseEntity<Hotel> updateHotel(@RequestBody Hotel hotel) {
		return hotelService.updateHotel(hotel);
	}
	
	@DeleteMapping(value="/deleteHotel",consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public void deleteHotel(@RequestBody Hotel hotel) {
		if(null!=hotel && null!=hotel.getId()) {
			hotelService.deleteHotel(hotel);
		}
	}
	
}
