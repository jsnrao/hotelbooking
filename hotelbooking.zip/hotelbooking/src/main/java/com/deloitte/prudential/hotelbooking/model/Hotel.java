package com.deloitte.prudential.hotelbooking.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "hotel")
public class Hotel {
	
    @Id
    private String id;
    private String hotelName;
	/**
	 * 
	 */
	public Hotel() {
		super();
	}
	/**
	 * @param id
	 * @param hotelName
	 */
	public Hotel( String hotelName) {
		super();
		this.hotelName = hotelName;
	}
	/**
	 * @param id
	 * @param hotelName
	 */
	public Hotel( String hotelName,String id) {
		super();
		this.id = id;
		this.hotelName = hotelName;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the hotelName
	 */
	public String getHotelName() {
		return hotelName;
	}
	/**
	 * @param hotelName the hotelName to set
	 */
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Hotel [id=" + id + ", hotelName=" + hotelName + "]";
	}
    
	
	
}
