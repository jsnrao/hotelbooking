package com.deloitte.prudential.hotelbooking.model;

import javax.validation.constraints.NotNull;
/**Booking Entity*/
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "booking")
public class Booking {

    @Id
    public String id;
    public int noOfNights;
    public boolean bookingStatus;
    @NotNull
    @DBRef
    private Hotel hotel;
    @DBRef
    @NotNull
    private Customer customer;
    
	/**
	 * 
	 */
	public Booking() {
		super();
	}

	/**
	 * @param id
	 * @param noOfNights
	 * @param bookingStatus
	 * @param hotel
	 * @param customer
	 */
	public Booking(int noOfNights, boolean bookingStatus, Hotel hotel, Customer customer) {
		super();
		this.noOfNights = noOfNights;
		this.bookingStatus = bookingStatus;
		this.hotel = hotel;
		this.customer = customer;
	}



	/**
	 * @param id
	 * @param noOfNights
	 * @param bookingStatus
	 * @param hotel
	 * @param customer
	 */
	public Booking(String id, int noOfNights, boolean bookingStatus, @NotNull Hotel hotel, @NotNull Customer customer) {
		super();
		this.id = id;
		this.noOfNights = noOfNights;
		this.bookingStatus = bookingStatus;
		this.hotel = hotel;
		this.customer = customer;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the noOfNights
	 */
	public int getNoOfNights() {
		return noOfNights;
	}

	/**
	 * @param noOfNights the noOfNights to set
	 */
	public void setNoOfNights(int noOfNights) {
		this.noOfNights = noOfNights;
	}

	/**
	 * @return the bookingStatus
	 */
	public boolean isBookingStatus() {
		return bookingStatus;
	}

	/**
	 * @param bookingStatus the bookingStatus to set
	 */
	public void setBookingStatus(boolean bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	/**
	 * @return the hotel
	 */
	public Hotel getHotel() {
		return hotel;
	}

	/**
	 * @param hotel the hotel to set
	 */
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	/**
	 * @return the customer
	 */
	public Customer getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Booking [id=" + id + ", noOfNights=" + noOfNights + ", bookingStatus=" + bookingStatus + ", hotel="
				+ hotel + ", customer=" + customer + "]";
	}

	

    
    
    
    
}
