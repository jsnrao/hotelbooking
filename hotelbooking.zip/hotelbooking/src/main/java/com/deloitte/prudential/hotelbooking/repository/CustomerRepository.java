package com.deloitte.prudential.hotelbooking.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.deloitte.prudential.hotelbooking.model.Customer;

public interface CustomerRepository extends MongoRepository<Customer, String> {

    public Customer findByCustomerName(String customerName);
    public List<Customer> findByEmail(String email);

}
