package com.deloitte.prudential.hotelbooking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.prudential.hotelbooking.model.Booking;
import com.deloitte.prudential.hotelbooking.service.BookingService;
import com.deloitte.prudential.hotelbooking.service.NotificationService;

/**
 * Controller for booking the hotel
 * @author jsnsa
 *
 */
@RestController
public class BookingController {

	@Autowired
	private BookingService  bookingService;
	
	
	
	@GetMapping(value="/fetchBookingDetails", produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public List<Booking> getBookingDetails() {
		return bookingService.fetchAllBooking();
	}
	
	@GetMapping(value="/fetchBookingById", produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public Optional<Booking> getBookingById(@PathVariable (value="id")String id) {
		return bookingService.findBookingById(id);
	}
	
	@PostMapping(value="/saveBookingDetails" , produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    }, consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public ResponseEntity<Booking> saveBooking(@RequestBody Booking booking) {
		return bookingService.saveBooking(booking);
	}
	
	@PutMapping(value="/updateBookingDetails", produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    }, consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public ResponseEntity<Booking> updateBooking(@RequestBody Booking booking) {
		return bookingService.updateBooking(booking);
			
	}
	
	@DeleteMapping(value="/deleteBooking", consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public void deleteBooking(@RequestBody Booking booking) {
		if (null != booking && null != booking.getId() && null != booking.getCustomer()
				&& null != booking.getCustomer().getId() && null != booking.getHotel()
				&& null != booking.getHotel().getId()) {
			 bookingService.deleteBooking(booking);
			
		}
		
	}
}
