package com.deloitte.prudential.hotelbooking.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.deloitte.prudential.hotelbooking.model.Booking;

public interface BookingRepository extends MongoRepository<Booking, String> {

}
