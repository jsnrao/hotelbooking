package com.deloitte.prudential.hotelbooking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.prudential.hotelbooking.model.Customer;
import com.deloitte.prudential.hotelbooking.service.CustomerService;

/**
 * Controller for Customer creation/updation/deletion/fetching all the customers
 * @author jsnsa
 *
 */
@RestController
public class CustomerContoller {

	@Autowired
	private CustomerService customerService;

	@GetMapping(value = "/fetchCustomerDetails", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Customer> getCustomerDetails() {
		return customerService.fetchAllCustomer();
	}

	@GetMapping(value = "/fetchCustomer" , produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public Optional<Customer> fetchByCustomerId(@PathVariable (value = "id")String id) {
		return customerService.findCustomerById(id);
	}

	@PostMapping(value = "/saveCustomerDetails" , produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    }, consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public ResponseEntity<Customer> saveCustomer(@RequestBody Customer customer) {
		return customerService.saveCustomer(customer);
	}

	@PutMapping(value = "/updateCustomerDetails" , produces = {
	        MediaType.APPLICATION_JSON_VALUE
	    }, consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer) {
		
		return customerService.updateCustomer(customer);
	}

	@DeleteMapping(value = "/deleteCustomer" , consumes = {
	        MediaType.APPLICATION_JSON_VALUE
	    })
	public void deleteCustomer(@RequestBody Customer customer) {
		if (null != customer && null != customer.getId()) {
			customerService.deleteCustomer(customer);
		}

	}
}
